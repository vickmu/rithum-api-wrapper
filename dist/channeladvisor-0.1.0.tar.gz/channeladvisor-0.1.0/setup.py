from setuptools import setup, find_packages

setup(
    name='channeladvisor',
    version='0.1.0',
    author='Vick Mu',
    author_email='arbi3400@gmail.com',
    packages=find_packages(),
    license='LICENSE',
    description='A Python package for accessing the ChannelAdvisor RESTful API',
    long_description=open('README.md').read(),
    install_requires=[
        # Your package dependencies
    ],
)
