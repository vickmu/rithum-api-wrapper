class MutationType:
    UPDATE = "update"
    CREATE = "create"
    UPDATE_QUANTITY = "update_quantity"
    
class ExportType:
    PRODUCT = "product"
    INVENTORY = "inventory"
    APQ = 'apq'
    
class ClientTypes: 
    PRODUCT = "product"
    ORDER = "order" 
    EXPORT = "export"
    BASE = "base"
