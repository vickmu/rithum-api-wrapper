class PaymentStatus:
    Submitted = 'Submitted'
    Cleared = 'Cleared'
    Failed = 'Failed'
    Refunded = 'Refunded'
    NotYetSubmitted = 'NotYetSubmitted'